
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { getDashboardStats, getRecentActivities } from '../../../lib/firebaseAdmin';

interface AdminDashboardProps {
  userRole: string;
}

export default function AdminDashboard({ userRole }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [dashboardStats, setDashboardStats] = useState({
    totalStudents: 0,
    totalCompanies: 0,
    totalPlacements: 0,
    placementRate: '0'
  });
  const [recentActivities, setRecentActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [stats, activities] = await Promise.all([
          getDashboardStats(),
          getRecentActivities(5)
        ]);
        
        setDashboardStats(stats);
        setRecentActivities(activities);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        // Fallback to demo data
        setDashboardStats({
          totalStudents: 1200,
          totalCompanies: 85,
          totalPlacements: 950,
          placementRate: '92.3'
        });
        setRecentActivities([
          { action: 'New company registration', company: 'Mahindra Tech', time: '2 hours ago', type: 'company' },
          { action: 'Student placement confirmed', student: 'Arjun Patil', company: 'TCS', time: '4 hours ago', type: 'placement' },
          { action: 'Interview scheduled', student: 'Priya Jadhav', company: 'Infosys', time: '6 hours ago', type: 'interview' },
          { action: 'New student registration', student: 'Vikram Kale', department: 'Mechanical Engineering', time: '8 hours ago', type: 'student' },
          { action: 'Company profile updated', company: 'L&T Infotech', time: '1 day ago', type: 'company' }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('adminAuth');
    router.push('/admin');
  };

  const getRoleTitle = (role: string) => {
    switch (role) {
      case 'admin': return 'System Administrator';
      case 'placement': return 'Placement Officer';
      case 'coordinator': return 'Department Coordinator';
      default: return 'Admin';
    }
  };

  const getPermissions = (role: string) => {
    switch (role) {
      case 'admin':
        return ['manage_users', 'manage_companies', 'manage_placements', 'view_analytics', 'system_settings'];
      case 'placement':
        return ['manage_companies', 'manage_placements', 'view_analytics', 'manage_interviews'];
      case 'coordinator':
        return ['view_students', 'manage_placements', 'view_analytics'];
      default:
        return [];
    }
  };

  const permissions = getPermissions(userRole);

  const displayStats = [
    { title: 'Total Students', value: dashboardStats.totalStudents.toString(), change: '+8%', icon: 'ri-user-line', color: 'blue' },
    { title: 'Active Companies', value: dashboardStats.totalCompanies.toString(), change: '+12%', icon: 'ri-building-line', color: 'green' },
    { title: 'Placements This Year', value: dashboardStats.totalPlacements.toString(), change: '+18%', icon: 'ri-briefcase-line', color: 'purple' },
    { title: 'Placement Rate', value: `${dashboardStats.placementRate}%`, change: '+5%', icon: 'ri-calendar-line', color: 'orange' }
  ];

  const quickActions = [
    { title: 'Add New Company', icon: 'ri-building-add-line', action: 'add_company', color: 'bg-blue-500' },
    { title: 'Schedule Interview', icon: 'ri-calendar-event-line', action: 'schedule_interview', color: 'bg-green-500' },
    { title: 'Send Notification', icon: 'ri-notification-line', action: 'send_notification', color: 'bg-purple-500' },
    { title: 'Generate Report', icon: 'ri-file-chart-line', action: 'generate_report', color: 'bg-orange-500' }
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/" className="text-xl font-bold text-blue-600" style={{ fontFamily: 'Pacifico, serif' }}>
                Dr. D.Y. Patil COE
              </Link>
              <div className="h-6 w-px bg-gray-300"></div>
              <span className="text-gray-600">Admin Dashboard</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                <span className="font-medium">{getRoleTitle(userRole)}</span>
              </div>
              <button
                onClick={handleLogout}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Firebase Dashboard</h1>
          <p className="text-gray-600">Real-time data from Firebase for Dr. D.Y. Patil COE placement activities.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {displayStats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg bg-${stat.color}-100 flex items-center justify-center`}>
                  <i className={`${stat.icon} text-${stat.color}-600 text-xl`}></i>
                </div>
                <span className="text-green-600 text-sm font-medium">{stat.change}</span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
              <p className="text-gray-600 text-sm">{stat.title}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Recent Activities</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {recentActivities.map((activity: any, index) => (
                    <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <i className={`ri-${activity.type === 'company' ? 'building' : activity.type === 'placement' ? 'briefcase' : activity.type === 'interview' ? 'calendar' : 'user'}-line text-blue-600`}></i>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                        <p className="text-xs text-gray-600">
                          {activity.company && `${activity.company} • `}
                          {activity.student && `${activity.student} • `}
                          {activity.department && `${activity.department} • `}
                          {activity.time}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div>
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 gap-4">
                  {quickActions.map((action, index) => (
                    <button
                      key={index}
                      className="flex items-center space-x-3 p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
                      onClick={() => console.log('Action:', action.action)}
                    >
                      <div className={`w-10 h-10 ${action.color} rounded-lg flex items-center justify-center`}>
                        <i className={`${action.icon} text-white`}></i>
                      </div>
                      <span className="text-sm font-medium text-gray-900">{action.title}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 mt-6">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Firebase Status</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Firebase Connection</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-green-600">Connected</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Firestore Database</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-green-600">Active</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Authentication</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-green-600">Enabled</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Data Sync</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-green-600">Real-time</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Navigation</h2>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
              <Link href="/students" className="flex items-center space-x-3 p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                  <i className="ri-user-line text-white"></i>
                </div>
                <span className="text-sm font-medium text-gray-900">Students</span>
              </Link>
              <Link href="/companies" className="flex items-center space-x-3 p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                  <i className="ri-building-line text-white"></i>
                </div>
                <span className="text-sm font-medium text-gray-900">Companies</span>
              </Link>
              <Link href="/placements" className="flex items-center space-x-3 p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                  <i className="ri-briefcase-line text-white"></i>
                </div>
                <span className="text-sm font-medium text-gray-900">Placements</span>
              </Link>
              <Link href="/analytics" className="flex items-center space-x-3 p-4 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
                  <i className="ri-bar-chart-line text-white"></i>
                </div>
                <span className="text-sm font-medium text-gray-900">Analytics</span>
              </Link>
              <Link href="/" className="flex items-center space-x-3 p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-gray-500 rounded-lg flex items-center justify-center">
                  <i className="ri-home-line text-white"></i>
                </div>
                <span className="text-sm font-medium text-gray-900">Home</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
