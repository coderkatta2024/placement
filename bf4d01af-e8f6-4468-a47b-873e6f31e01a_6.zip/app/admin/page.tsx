
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import AdminLogin from './AdminLogin';

export default function AdminPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const router = useRouter();

  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
    router.push('/admin/dashboard');
  };

  if (isLoggedIn) {
    return null;
  }

  return <AdminLogin onLoginSuccess={handleLoginSuccess} />;
}