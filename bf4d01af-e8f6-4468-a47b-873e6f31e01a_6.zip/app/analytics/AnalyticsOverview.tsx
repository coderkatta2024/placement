
'use client';

export default function AnalyticsOverview() {
  const stats = [
    {
      title: 'Total Placements',
      value: '342',
      change: '+12.5%',
      trend: 'up',
      icon: 'ri-user-star-line'
    },
    {
      title: 'Active Companies',
      value: '87',
      change: '+8.2%',
      trend: 'up',
      icon: 'ri-building-line'
    },
    {
      title: 'Placement Rate',
      value: '78.5%',
      change: '+5.3%',
      trend: 'up',
      icon: 'ri-trophy-line'
    },
    {
      title: 'Average Package',
      value: '$65,000',
      change: '+15.7%',
      trend: 'up',
      icon: 'ri-money-dollar-circle-line'
    },
    {
      title: 'Registered Students',
      value: '1,247',
      change: '+22.1%',
      trend: 'up',
      icon: 'ri-graduation-cap-line'
    },
    {
      title: 'Job Openings',
      value: '156',
      change: '+9.4%',
      trend: 'up',
      icon: 'ri-briefcase-line'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Key Metrics Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 border border-blue-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <div className="flex items-center mt-2">
                  <span className={`text-sm font-medium ${stat.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {stat.change}
                  </span>
                  <span className="text-xs text-gray-500 ml-2">vs last month</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className={`${stat.icon} text-blue-600 text-xl`}></i>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
