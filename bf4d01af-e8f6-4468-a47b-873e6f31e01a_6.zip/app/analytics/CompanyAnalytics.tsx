
'use client';

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

export default function CompanyAnalytics() {
  const companyTypeData = [
    { name: 'Tech Companies', value: 45, color: '#3b82f6' },
    { name: 'Consulting', value: 22, color: '#10b981' },
    { name: 'Finance', value: 18, color: '#f59e0b' },
    { name: 'Manufacturing', value: 15, color: '#ef4444' }
  ];

  const topCompanies = [
    { name: 'Microsoft', hires: 23, package: '$85,000' },
    { name: 'Google', hires: 18, package: '$92,000' },
    { name: 'Amazon', hires: 16, package: '$78,000' },
    { name: 'Apple', hires: 14, package: '$88,000' },
    { name: 'Meta', hires: 12, package: '$95,000' },
    { name: 'Tesla', hires: 10, package: '$82,000' },
    { name: 'Netflix', hires: 8, package: '$90,000' },
    { name: 'Spotify', hires: 7, package: '$75,000' }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Company Analytics</h3>
      
      <div className="mb-8">
        <h4 className="text-md font-medium text-gray-800 mb-4">Company Distribution by Industry</h4>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={companyTypeData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                dataKey="value"
                label={({ name, value }) => `${name}: ${value}%`}
              >
                {companyTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div>
        <h4 className="text-md font-medium text-gray-800 mb-4">Top Recruiting Companies</h4>
        <div className="space-y-3">
          {topCompanies.map((company, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                  <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">{company.name}</p>
                  <p className="text-sm text-gray-600">{company.hires} hires</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-green-600">{company.package}</p>
                <p className="text-sm text-gray-500">avg. package</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
