
'use client';

import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

export default function PlacementStats() {
  const monthlyData = [
    { month: 'Jan', placements: 28, applications: 156 },
    { month: 'Feb', placements: 32, applications: 178 },
    { month: 'Mar', placements: 45, applications: 203 },
    { month: 'Apr', placements: 38, applications: 187 },
    { month: 'May', placements: 52, applications: 234 },
    { month: 'Jun', placements: 41, applications: 198 },
    { month: 'Jul', placements: 48, applications: 221 },
    { month: 'Aug', placements: 55, applications: 267 },
    { month: 'Sep', placements: 43, applications: 205 },
    { month: 'Oct', placements: 49, applications: 223 },
    { month: 'Nov', placements: 58, applications: 278 },
    { month: 'Dec', placements: 51, applications: 245 }
  ];

  const departmentData = [
    { department: 'Computer Science', placed: 89, total: 112 },
    { department: 'Electronics', placed: 67, total: 89 },
    { department: 'Mechanical', placed: 54, total: 76 },
    { department: 'Civil', placed: 43, total: 65 },
    { department: 'Information Tech', placed: 76, total: 95 },
    { department: 'Electrical', placed: 38, total: 58 }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Placement Trends</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Area 
                type="monotone" 
                dataKey="placements" 
                stackId="1"
                stroke="#3b82f6" 
                fill="#3b82f6"
                fillOpacity={0.6}
              />
              <Area 
                type="monotone" 
                dataKey="applications" 
                stackId="2"
                stroke="#10b981" 
                fill="#10b981"
                fillOpacity={0.3}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center mt-4 space-x-6">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
            <span className="text-sm text-gray-600">Placements</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
            <span className="text-sm text-gray-600">Applications</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Department-wise Placement Rate</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={departmentData} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="department" type="category" width={100} />
              <Tooltip />
              <Bar dataKey="placed" fill="#3b82f6" />
              <Bar dataKey="total" fill="#e5e7eb" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center mt-4 space-x-6">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
            <span className="text-sm text-gray-600">Placed</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-gray-300 rounded-full mr-2"></div>
            <span className="text-sm text-gray-600">Total Students</span>
          </div>
        </div>
      </div>
    </div>
  );
}
