
'use client';

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function StudentAnalytics() {
  const skillsData = [
    { skill: 'JavaScript', demand: 89 },
    { skill: 'Python', demand: 76 },
    { skill: 'React', demand: 68 },
    { skill: 'Java', demand: 63 },
    { skill: 'SQL', demand: 58 },
    { skill: 'Node.js', demand: 52 },
    { skill: 'AWS', demand: 47 },
    { skill: 'Docker', demand: 41 }
  ];

  const placementsByGPA = [
    { gpa: '3.8-4.0', placed: 45, total: 52 },
    { gpa: '3.5-3.7', placed: 89, total: 112 },
    { gpa: '3.0-3.4', placed: 76, total: 98 },
    { gpa: '2.5-2.9', placed: 34, total: 67 },
    { gpa: '2.0-2.4', placed: 12, total: 28 }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Student Analytics</h3>
      
      <div className="mb-8">
        <h4 className="text-md font-medium text-gray-800 mb-4">Most In-Demand Skills</h4>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={skillsData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="skill" angle={-45} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="demand" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div>
        <h4 className="text-md font-medium text-gray-800 mb-4">Placement Rate by GPA</h4>
        <div className="space-y-3">
          {placementsByGPA.map((item, index) => {
            const rate = ((item.placed / item.total) * 100).toFixed(1);
            return (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div className="w-16 text-sm font-medium text-gray-700">{item.gpa}</div>
                  <div className="flex-1 ml-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-gray-600">{item.placed} of {item.total} placed</span>
                      <span className="text-sm font-medium text-blue-600">{rate}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${rate}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
