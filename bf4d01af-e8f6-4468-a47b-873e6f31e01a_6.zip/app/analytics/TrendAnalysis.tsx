
'use client';

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function TrendAnalysis() {
  const yearlyTrends = [
    { year: '2020', placements: 234, companies: 45, avgPackage: 52000 },
    { year: '2021', placements: 267, companies: 52, avgPackage: 55000 },
    { year: '2022', placements: 298, companies: 61, avgPackage: 58000 },
    { year: '2023', placements: 321, companies: 74, avgPackage: 62000 },
    { year: '2024', placements: 342, companies: 87, avgPackage: 65000 }
  ];

  const insights = [
    {
      title: 'Placement Growth',
      value: '46%',
      description: 'Increase in placements over the last 5 years',
      icon: 'ri-trending-up-line',
      color: 'text-green-600'
    },
    {
      title: 'Company Partners',
      value: '93%',
      description: 'Growth in recruiting companies',
      icon: 'ri-building-2-line',
      color: 'text-blue-600'
    },
    {
      title: 'Package Increase',
      value: '25%',
      description: 'Average salary package growth',
      icon: 'ri-money-dollar-circle-line',
      color: 'text-purple-600'
    },
    {
      title: 'Success Rate',
      value: '78.5%',
      description: 'Current placement success rate',
      icon: 'ri-trophy-line',
      color: 'text-orange-600'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">5-Year Trend Analysis</h3>
      
      <div className="mb-8">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={yearlyTrends}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="year" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="placements" 
                stroke="#3b82f6" 
                strokeWidth={3}
                dot={{ r: 6 }}
              />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="companies" 
                stroke="#10b981" 
                strokeWidth={3}
                dot={{ r: 6 }}
              />
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="avgPackage" 
                stroke="#f59e0b" 
                strokeWidth={3}
                dot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center mt-4 space-x-8">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
            <span className="text-sm text-gray-600">Placements</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
            <span className="text-sm text-gray-600">Companies</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
            <span className="text-sm text-gray-600">Avg Package ($)</span>
          </div>
        </div>
      </div>

      <div>
        <h4 className="text-md font-medium text-gray-800 mb-4">Key Insights</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {insights.map((insight, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center mr-3">
                  <i className={`${insight.icon} ${insight.color} text-xl`}></i>
                </div>
                <div>
                  <p className={`text-2xl font-bold ${insight.color}`}>{insight.value}</p>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900 mb-1">{insight.title}</p>
                <p className="text-xs text-gray-600">{insight.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
