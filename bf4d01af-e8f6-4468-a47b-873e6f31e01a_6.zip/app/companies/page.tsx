
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState } from 'react';

interface Company {
  id: string;
  name: string;
  logo: string;
  industry: string;
  location: string;
  website: string;
  description: string;
  jobOpenings: number;
  requirements: string[];
  benefits: string[];
  package: string;
  applicationDeadline: string;
  status: 'active' | 'closed' | 'upcoming';
}

export default function CompaniesPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterIndustry, setFilterIndustry] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  
  // Mock data
  const companies: Company[] = [
    {
      id: 'C001',
      name: 'Google',
      logo: 'G',
      industry: 'Technology',
      location: 'Mountain View, CA',
      website: 'https://google.com',
      description: 'Leading technology company focused on internet services and products.',
      jobOpenings: 15,
      requirements: ['CS/IT Background', 'Strong Programming Skills', 'Problem Solving'],
      benefits: ['Health Insurance', 'Stock Options', 'Flexible Hours', 'Learning Budget'],
      package: '$120,000 - $180,000',
      applicationDeadline: '2024-03-15',
      status: 'active'
    },
    {
      id: 'C002',
      name: 'Microsoft',
      logo: 'M',
      industry: 'Technology',
      location: 'Redmond, WA',
      website: 'https://microsoft.com',
      description: 'Multinational technology company developing software and cloud services.',
      jobOpenings: 12,
      requirements: ['Engineering Degree', 'Software Development', 'Team Collaboration'],
      benefits: ['Healthcare', 'Retirement Plans', 'Professional Development', 'Remote Work'],
      package: '$110,000 - $160,000',
      applicationDeadline: '2024-03-20',
      status: 'active'
    },
    {
      id: 'C003',
      name: 'Amazon',
      logo: 'A',
      industry: 'E-commerce',
      location: 'Seattle, WA',
      website: 'https://amazon.com',
      description: 'Global e-commerce and cloud computing company.',
      jobOpenings: 18,
      requirements: ['Bachelor\'s Degree', 'Analytical Skills', 'Customer Focus'],
      benefits: ['Medical Coverage', 'Career Growth', 'Employee Discounts', 'Parental Leave'],
      package: '$95,000 - $150,000',
      applicationDeadline: '2024-03-25',
      status: 'active'
    },
    {
      id: 'C004',
      name: 'Apple',
      logo: 'A',
      industry: 'Technology',
      location: 'Cupertino, CA',
      website: 'https://apple.com',
      description: 'Innovative technology company designing consumer electronics and software.',
      jobOpenings: 8,
      requirements: ['Technical Excellence', 'Innovation Mindset', 'Attention to Detail'],
      benefits: ['Comprehensive Benefits', 'Employee Purchase Program', 'Wellness Programs'],
      package: '$130,000 - $200,000',
      applicationDeadline: '2024-02-28',
      status: 'closed'
    },
    {
      id: 'C005',
      name: 'Tesla',
      logo: 'T',
      industry: 'Automotive',
      location: 'Austin, TX',
      website: 'https://tesla.com',
      description: 'Electric vehicle and clean energy company.',
      jobOpenings: 10,
      requirements: ['Engineering Background', 'Sustainability Focus', 'Innovation'],
      benefits: ['Stock Options', 'Healthcare', 'Gym Membership', 'Free Charging'],
      package: '$100,000 - $170,000',
      applicationDeadline: '2024-04-01',
      status: 'upcoming'
    },
    {
      id: 'C006',
      name: 'Netflix',
      logo: 'N',
      industry: 'Entertainment',
      location: 'Los Gatos, CA',
      website: 'https://netflix.com',
      description: 'Leading streaming entertainment service.',
      jobOpenings: 6,
      requirements: ['Creative Thinking', 'Data Analysis', 'User Experience'],
      benefits: ['Unlimited Vacation', 'Parental Leave', 'Learning Budget', 'Wellness'],
      package: '$115,000 - $175,000',
      applicationDeadline: '2024-03-30',
      status: 'active'
    }
  ];
  
  const industries = ['Technology', 'E-commerce', 'Automotive', 'Entertainment', 'Finance'];
  
  const filteredCompanies = companies.filter(company => {
    const matchesSearch = company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         company.industry.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         company.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesIndustry = filterIndustry === 'all' || company.industry === filterIndustry;
    const matchesStatus = filterStatus === 'all' || company.status === filterStatus;
    
    return matchesSearch && matchesIndustry && matchesStatus;
  });
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-red-100 text-red-800';
      case 'upcoming': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Company Listings</h1>
          <p className="text-gray-600">Discover exciting career opportunities with top companies</p>
        </div>
        
        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <div className="w-5 h-5 flex items-center justify-center">
                    <i className="ri-search-line text-gray-400"></i>
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="Search companies..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                />
              </div>
            </div>
            
            <div className="flex gap-4">
              <select
                value={filterIndustry}
                onChange={(e) => setFilterIndustry(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
              >
                <option value="all">All Industries</option>
                {industries.map(industry => (
                  <option key={industry} value={industry}>{industry}</option>
                ))}
              </select>
              
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="closed">Closed</option>
                <option value="upcoming">Upcoming</option>
              </select>
            </div>
          </div>
        </div>
        
        {/* Companies Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredCompanies.map(company => (
            <div key={company.id} className="bg-white rounded-xl shadow-md p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center text-white text-2xl font-bold">
                    {company.logo}
                  </div>
                  <div className="ml-4">
                    <h3 className="text-xl font-bold text-gray-900">{company.name}</h3>
                    <p className="text-gray-600">{company.industry}</p>
                    <p className="text-sm text-gray-500">{company.location}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(company.status)}`}>
                  {company.status.charAt(0).toUpperCase() + company.status.slice(1)}
                </span>
              </div>
              
              <p className="text-gray-700 mb-6">{company.description}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Job Openings</h4>
                  <p className="text-blue-600 font-bold">{company.jobOpenings} positions</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Salary Range</h4>
                  <p className="text-green-600 font-bold">{company.package}</p>
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="font-semibold text-gray-900 mb-2">Requirements</h4>
                <div className="flex flex-wrap gap-2">
                  {company.requirements.map(req => (
                    <span key={req} className="bg-red-100 text-red-800 text-sm px-3 py-1 rounded-full">
                      {req}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="font-semibold text-gray-900 mb-2">Benefits</h4>
                <div className="flex flex-wrap gap-2">
                  {company.benefits.slice(0, 3).map(benefit => (
                    <span key={benefit} className="bg-green-100 text-green-800 text-sm px-3 py-1 rounded-full">
                      {benefit}
                    </span>
                  ))}
                  {company.benefits.length > 3 && (
                    <span className="bg-gray-100 text-gray-600 text-sm px-3 py-1 rounded-full">
                      +{company.benefits.length - 3} more
                    </span>
                  )}
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div className="text-sm text-gray-600">
                  <span className="font-medium">Application Deadline: </span>
                  {new Date(company.applicationDeadline).toLocaleDateString()}
                </div>
                <div className="flex gap-2">
                  <button className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                    Apply Now
                  </button>
                  <button className="border border-gray-300 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {filteredCompanies.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-building-line text-2xl text-gray-400"></i>
            </div>
            <p className="text-gray-600">No companies found matching your criteria.</p>
          </div>
        )}
      </div>
      
      <Footer />
    </div>
  );
}
