
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-700 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20engineering%20college%20campus%20with%20students%20walking%20confidently%20towards%20their%20future%20careers%2C%20Dr.%20D.Y.%20Patil%20College%20of%20Engineering%20building%20in%20background%2C%20bright%20sunny%20day%2C%20professional%20atmosphere%2C%20diverse%20group%20of%20engineering%20students%20carrying%20laptops%20and%20books%2C%20contemporary%20architecture%2C%20clean%20and%20inspiring%20environment%2C%20soft%20natural%20lighting%2C%20hopeful%20and%20ambitious%20mood%2C%20Indian%20college%20campus&width=1920&height=1080&seq=dypatil-hero&orientation=landscape')`,
            backgroundPosition: 'center'
          }}
        >
          <div className="absolute inset-0 bg-blue-900/40"></div>
        </div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Welcome to 
            <span className="text-yellow-300"> Dr. D.Y. Patil College</span>
          </h1>
          <h2 className="text-xl md:text-2xl font-semibold mb-4 text-gray-100">
            College of Engineering, Salokhenagar, Kolhapur
          </h2>
          <p className="text-lg md:text-xl mb-8 text-gray-100">
            Connect with top companies, showcase your engineering skills, and launch your career through our comprehensive placement portal.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/students" className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap">
              Register as Student
            </Link>
            <Link href="/companies" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap">
              Browse Companies
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Engineering Excellence Meets Career Success
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our comprehensive placement platform provides all the tools engineering students and companies need for seamless recruitment processes.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-user-add-line text-2xl text-blue-600"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4">Student Registration</h3>
              <p className="text-gray-600 mb-4">
                Easy registration process with academic profile creation, project showcase, and technical skill assessment.
              </p>
              <Link href="/students" className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
                Get Started →
              </Link>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-building-line text-2xl text-green-600"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4">Company Partnerships</h3>
              <p className="text-gray-600 mb-4">
                Connect with leading engineering companies with detailed job descriptions and technical requirements.
              </p>
              <Link href="/companies" className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
                Explore Companies →
              </Link>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-calendar-event-line text-2xl text-purple-600"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4">Placement Drives</h3>
              <p className="text-gray-600 mb-4">
                Stay updated with campus recruitment drives, technical interviews, and placement schedules.
              </p>
              <Link href="/placements" className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
                View Schedule →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Placement Success</h2>
            <p className="text-blue-100 text-lg">Engineering careers built on excellence</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">1,200+</div>
              <div className="text-blue-100">Engineering Students</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">85+</div>
              <div className="text-blue-100">Industry Partners</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">950+</div>
              <div className="text-blue-100">Successful Placements</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">92%</div>
              <div className="text-blue-100">Placement Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Recent Placements */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Recent Success Stories
            </h2>
            <p className="text-xl text-gray-600">
              Celebrating our engineering graduates' achievements and career milestones
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-xl">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                  A
                </div>
                <div className="ml-4">
                  <h3 className="font-semibold">Arjun Patil</h3>
                  <p className="text-gray-600">Computer Engineering</p>
                </div>
              </div>
              <p className="text-gray-700 mb-2">Placed at <span className="font-semibold">TCS</span></p>
              <p className="text-sm text-gray-500">Software Engineer • ₹6.5 LPA</p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold">
                  P
                </div>
                <div className="ml-4">
                  <h3 className="font-semibold">Priya Jadhav</h3>
                  <p className="text-gray-600">Electronics Engineering</p>
                </div>
              </div>
              <p className="text-gray-700 mb-2">Placed at <span className="font-semibold">Infosys</span></p>
              <p className="text-sm text-gray-500">Systems Engineer • ₹5.2 LPA</p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                  V
                </div>
                <div className="ml-4">
                  <h3 className="font-semibold">Vikram Kale</h3>
                  <p className="text-gray-600">Mechanical Engineering</p>
                </div>
              </div>
              <p className="text-gray-700 mb-2">Placed at <span className="font-semibold">Mahindra</span></p>
              <p className="text-sm text-gray-500">Design Engineer • ₹4.8 LPA</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-700 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Launch Your Engineering Career?
          </h2>
          <p className="text-xl mb-8 text-gray-100">
            Join hundreds of Dr. D.Y. Patil engineering graduates who have found their dream jobs through our platform.
          </p>
          <Link href="/students" className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap">
            Register Now
          </Link>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}