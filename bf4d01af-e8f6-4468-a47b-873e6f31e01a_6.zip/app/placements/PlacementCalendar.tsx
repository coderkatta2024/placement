
'use client';

import { useState } from 'react';

export default function PlacementCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  const events = [
    {
      id: 1,
      title: 'TechCorp Solutions - Technical Interview',
      date: '2024-02-20',
      time: '10:00 AM',
      type: 'interview',
      location: 'Room 301',
      company: 'TechCorp Solutions',
      candidates: 25
    },
    {
      id: 2,
      title: 'DataFlow Analytics - Pre-placement Talk',
      date: '2024-02-22',
      time: '2:00 PM',
      type: 'presentation',
      location: 'Auditorium',
      company: 'DataFlow Analytics',
      candidates: 150
    },
    {
      id: 3,
      title: 'CloudTech Systems - HR Round',
      date: '2024-02-25',
      time: '9:00 AM',
      type: 'interview',
      location: 'Conference Room A',
      company: 'CloudTech Systems',
      candidates: 15
    },
    {
      id: 4,
      title: 'FinanceFlow Inc - Written Test',
      date: '2024-02-28',
      time: '11:00 AM',
      type: 'test',
      location: 'Computer Lab 1',
      company: 'FinanceFlow Inc',
      candidates: 89
    },
    {
      id: 5,
      title: 'StartupX - Portfolio Review',
      date: '2024-03-02',
      time: '3:00 PM',
      type: 'review',
      location: 'Room 205',
      company: 'StartupX',
      candidates: 20
    },
    {
      id: 6,
      title: 'GlobalTech - Final Interview',
      date: '2024-03-05',
      time: '1:00 PM',
      type: 'interview',
      location: 'Room 401',
      company: 'GlobalTech Solutions',
      candidates: 8
    }
  ];

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case 'interview': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'test': return 'bg-green-100 text-green-800 border-green-200';
      case 'presentation': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'review': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case 'interview': return 'ri-user-voice-line';
      case 'test': return 'ri-file-text-line';
      case 'presentation': return 'ri-presentation-line';
      case 'review': return 'ri-eye-line';
      default: return 'ri-calendar-event-line';
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day);
    }
    
    return days;
  };

  const getEventsForDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return events.filter(event => event.date === dateString);
  };

  const days = getDaysInMonth(currentDate);
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const navigateMonth = (direction: number) => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + direction, 1));
  };

  const todayEvents = getEventsForDate(selectedDate);
  const upcomingEvents = events.filter(event => new Date(event.date) > new Date()).slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-white border rounded-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">
                {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h2>
              <div className="flex gap-2">
                <button
                  onClick={() => navigateMonth(-1)}
                  className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
                >
                  <div className="w-4 h-4 flex items-center justify-center">
                    <i className="ri-arrow-left-line"></i>
                  </div>
                </button>
                <button
                  onClick={() => navigateMonth(1)}
                  className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
                >
                  <div className="w-4 h-4 flex items-center justify-center">
                    <i className="ri-arrow-right-line"></i>
                  </div>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-1 mb-4">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="p-2 text-center text-sm font-medium text-gray-600">
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-1">
              {days.map((day, index) => {
                if (day === null) {
                  return <div key={index} className="p-2 h-24"></div>;
                }

                const cellDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
                const dayEvents = getEventsForDate(cellDate);
                const isToday = cellDate.toDateString() === new Date().toDateString();
                const isSelected = cellDate.toDateString() === selectedDate.toDateString();

                return (
                  <div
                    key={day}
                    onClick={() => setSelectedDate(cellDate)}
                    className={`p-2 h-24 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors ${
                      isToday ? 'bg-blue-50 border-blue-200' : 'border-gray-200'
                    } ${isSelected ? 'ring-2 ring-blue-500' : ''}`}
                  >
                    <div className={`text-sm font-medium mb-1 ${isToday ? 'text-blue-600' : 'text-gray-900'}`}>
                      {day}
                    </div>
                    <div className="space-y-1">
                      {dayEvents.slice(0, 2).map(event => (
                        <div
                          key={event.id}
                          className={`text-xs px-1 py-0.5 rounded truncate ${getEventTypeColor(event.type)}`}
                        >
                          {event.title.split(' - ')[0]}
                        </div>
                      ))}
                      {dayEvents.length > 2 && (
                        <div className="text-xs text-gray-500">
                          +{dayEvents.length - 2} more
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {formatDate(selectedDate)}
            </h3>
            
            {todayEvents.length > 0 ? (
              <div className="space-y-3">
                {todayEvents.map(event => (
                  <div key={event.id} className={`p-3 rounded-lg border ${getEventTypeColor(event.type)}`}>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 flex items-center justify-center mt-0.5">
                        <i className={getEventTypeIcon(event.type)}></i>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{event.title}</h4>
                        <p className="text-xs opacity-75 mt-1">{event.time} • {event.location}</p>
                        <p className="text-xs opacity-75">{event.candidates} candidates</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="w-12 h-12 flex items-center justify-center mx-auto mb-3 bg-gray-100 rounded-full">
                  <i className="ri-calendar-line text-gray-400 text-xl"></i>
                </div>
                <p className="text-gray-500 text-sm">No events scheduled for this day</p>
              </div>
            )}
          </div>

          <div className="bg-white border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Events</h3>
            <div className="space-y-3">
              {upcomingEvents.map(event => (
                <div key={event.id} className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getEventTypeColor(event.type)}`}>
                    <div className="w-4 h-4 flex items-center justify-center">
                      <i className={getEventTypeIcon(event.type)}></i>
                    </div>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">{event.company}</h4>
                    <p className="text-xs text-gray-500">{new Date(event.date).toLocaleDateString()} • {event.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
