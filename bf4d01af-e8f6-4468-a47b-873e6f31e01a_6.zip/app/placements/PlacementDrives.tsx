
'use client';

import { useState } from 'react';

export default function PlacementDrives() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const placementDrives = [
    {
      id: 1,
      company: 'TechCorp Solutions',
      position: 'Software Engineer',
      package: '₹12 LPA',
      applicationDeadline: '2024-02-15',
      interviewDate: '2024-02-20',
      status: 'active',
      appliedCount: 145,
      selectedCount: 8,
      requirements: ['B.Tech CSE/IT', 'CGPA > 7.0', 'Full Stack Development'],
      location: 'Bangalore',
      type: 'Full-time'
    },
    {
      id: 2,
      company: 'DataFlow Analytics',
      position: 'Data Scientist',
      package: '₹15 LPA',
      applicationDeadline: '2024-02-18',
      interviewDate: '2024-02-25',
      status: 'active',
      appliedCount: 89,
      selectedCount: 5,
      requirements: ['B.Tech/M.Tech', 'Python/R', 'Machine Learning'],
      location: 'Hyderabad',
      type: 'Full-time'
    },
    {
      id: 3,
      company: 'CloudTech Systems',
      position: 'DevOps Engineer',
      package: '₹10 LPA',
      applicationDeadline: '2024-02-10',
      interviewDate: '2024-02-14',
      status: 'completed',
      appliedCount: 67,
      selectedCount: 12,
      requirements: ['B.Tech CSE', 'AWS/Azure', 'Docker/Kubernetes'],
      location: 'Pune',
      type: 'Full-time'
    },
    {
      id: 4,
      company: 'FinanceFlow Inc',
      position: 'Business Analyst',
      package: '₹8 LPA',
      applicationDeadline: '2024-02-22',
      interviewDate: '2024-02-28',
      status: 'upcoming',
      appliedCount: 0,
      selectedCount: 0,
      requirements: ['Any Graduate', 'Excel/SQL', 'Communication Skills'],
      location: 'Mumbai',
      type: 'Full-time'
    },
    {
      id: 5,
      company: 'StartupX',
      position: 'Frontend Developer',
      package: '₹7 LPA',
      applicationDeadline: '2024-02-25',
      interviewDate: '2024-03-02',
      status: 'upcoming',
      appliedCount: 0,
      selectedCount: 0,
      requirements: ['B.Tech CSE/IT', 'React/Angular', 'UI/UX Knowledge'],
      location: 'Remote',
      type: 'Full-time'
    },
    {
      id: 6,
      company: 'GlobalTech Solutions',
      position: 'Quality Assurance Engineer',
      package: '₹6 LPA',
      applicationDeadline: '2024-02-20',
      interviewDate: '2024-02-26',
      status: 'active',
      appliedCount: 78,
      selectedCount: 3,
      requirements: ['B.Tech CSE/IT', 'Manual Testing', 'Automation Tools'],
      location: 'Chennai',
      type: 'Full-time'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'upcoming': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredDrives = placementDrives.filter(drive => {
    const matchesSearch = drive.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         drive.position.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || drive.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <div className="w-5 h-5 flex items-center justify-center">
              <i className="ri-search-line text-gray-400"></i>
            </div>
          </div>
          <input
            type="text"
            placeholder="Search drives..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm pr-8"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="upcoming">Upcoming</option>
            <option value="completed">Completed</option>
          </select>
          
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap text-sm">
            <div className="w-4 h-4 flex items-center justify-center mr-2 inline-block">
              <i className="ri-add-line"></i>
            </div>
            Add Drive
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredDrives.map((drive) => (
          <div key={drive.id} className="bg-white border rounded-lg p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900">{drive.company}</h3>
                <p className="text-blue-600 font-medium">{drive.position}</p>
                <p className="text-green-600 font-semibold text-lg">{drive.package}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(drive.status)}`}>
                {drive.status.charAt(0).toUpperCase() + drive.status.slice(1)}
              </span>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-map-pin-line"></i>
                </div>
                {drive.location} • {drive.type}
              </div>

              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-calendar-line"></i>
                </div>
                Apply by: {new Date(drive.applicationDeadline).toLocaleDateString()}
              </div>

              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-video-line"></i>
                </div>
                Interview: {new Date(drive.interviewDate).toLocaleDateString()}
              </div>
            </div>

            <div className="mb-4">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Requirements:</h4>
              <div className="flex flex-wrap gap-2">
                {drive.requirements.map((req, index) => (
                  <span key={index} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                    {req}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t">
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <span className="flex items-center">
                  <div className="w-4 h-4 flex items-center justify-center mr-1">
                    <i className="ri-user-line"></i>
                  </div>
                  {drive.appliedCount} applied
                </span>
                <span className="flex items-center">
                  <div className="w-4 h-4 flex items-center justify-center mr-1">
                    <i className="ri-user-star-line"></i>
                  </div>
                  {drive.selectedCount} selected
                </span>
              </div>

              <div className="flex gap-2">
                <button className="text-blue-600 hover:text-blue-800 cursor-pointer text-sm">
                  <div className="w-4 h-4 flex items-center justify-center">
                    <i className="ri-eye-line"></i>
                  </div>
                </button>
                <button className="text-gray-600 hover:text-gray-800 cursor-pointer text-sm">
                  <div className="w-4 h-4 flex items-center justify-center">
                    <i className="ri-edit-line"></i>
                  </div>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredDrives.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 flex items-center justify-center mx-auto mb-4 bg-gray-100 rounded-full">
            <i className="ri-search-line text-gray-400 text-2xl"></i>
          </div>
          <p className="text-gray-500">No placement drives found matching your criteria</p>
        </div>
      )}
    </div>
  );
}
