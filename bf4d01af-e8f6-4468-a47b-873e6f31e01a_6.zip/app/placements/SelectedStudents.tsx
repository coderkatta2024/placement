
'use client';

import { useState } from 'react';

export default function SelectedStudents() {
  const [searchTerm, setSearchTerm] = useState('');
  const [companyFilter, setCompanyFilter] = useState('all');
  const [departmentFilter, setDepartmentFilter] = useState('all');

  const selectedStudents = [
    {
      id: 1,
      name: 'Rahul Sharma',
      rollNumber: 'CS2020001',
      department: 'Computer Science',
      cgpa: 8.9,
      company: 'TechCorp Solutions',
      position: 'Software Engineer',
      package: '₹12 LPA',
      selectionDate: '2024-02-20',
      joiningDate: '2024-07-01',
      status: 'confirmed',
      email: 'rahul.sharma@college.edu',
      phone: '+91 98765 43210',
      skills: ['React', 'Node.js', 'MongoDB', 'AWS'],
      photo: 'https://readdy.ai/api/search-image?query=professional%20headshot%20of%20young%20Indian%20male%20software%20engineer%20wearing%20formal%20shirt%2C%20clean%20studio%20background%2C%20confident%20expression%2C%20modern%20professional%20portrait&width=150&height=150&seq=student1&orientation=squarish'
    },
    {
      id: 2,
      name: 'Priya Patel',
      rollNumber: 'CS2020045',
      department: 'Computer Science',
      cgpa: 9.2,
      company: 'DataFlow Analytics',
      position: 'Data Scientist',
      package: '₹15 LPA',
      selectionDate: '2024-02-25',
      joiningDate: '2024-08-01',
      status: 'confirmed',
      email: 'priya.patel@college.edu',
      phone: '+91 98765 43211',
      skills: ['Python', 'Machine Learning', 'TensorFlow', 'SQL'],
      photo: 'https://readdy.ai/api/search-image?query=professional%20headshot%20of%20young%20Indian%20female%20data%20scientist%20wearing%20business%20attire%2C%20clean%20studio%20background%2C%20confident%20smile%2C%20modern%20professional%20portrait&width=150&height=150&seq=student2&orientation=squarish'
    },
    {
      id: 3,
      name: 'Amit Kumar',
      rollNumber: 'CS2020023',
      department: 'Computer Science',
      cgpa: 8.5,
      company: 'CloudTech Systems',
      position: 'DevOps Engineer',
      package: '₹10 LPA',
      selectionDate: '2024-02-14',
      joiningDate: '2024-06-15',
      status: 'confirmed',
      email: 'amit.kumar@college.edu',
      phone: '+91 98765 43212',
      skills: ['Docker', 'Kubernetes', 'AWS', 'Jenkins'],
      photo: 'https://readdy.ai/api/search-image?query=professional%20headshot%20of%20young%20Indian%20male%20DevOps%20engineer%20wearing%20formal%20shirt%2C%20clean%20studio%20background%2C%20friendly%20expression%2C%20modern%20professional%20portrait&width=150&height=150&seq=student3&orientation=squarish'
    },
    {
      id: 4,
      name: 'Sneha Reddy',
      rollNumber: 'ME2020012',
      department: 'Mechanical Engineering',
      cgpa: 8.7,
      company: 'FinanceFlow Inc',
      position: 'Business Analyst',
      package: '₹8 LPA',
      selectionDate: '2024-02-28',
      joiningDate: '2024-07-15',
      status: 'pending',
      email: 'sneha.reddy@college.edu',
      phone: '+91 98765 43213',
      skills: ['Excel', 'SQL', 'Power BI', 'Analytics'],
      photo: 'https://readdy.ai/api/search-image?query=professional%20headshot%20of%20young%20Indian%20female%20business%20analyst%20wearing%20professional%20blazer%2C%20clean%20studio%20background%2C%20confident%20demeanor%2C%20modern%20professional%20portrait&width=150&height=150&seq=student4&orientation=squarish'
    },
    {
      id: 5,
      name: 'Arjun Singh',
      rollNumber: 'CS2020067',
      department: 'Computer Science',
      cgpa: 8.3,
      company: 'StartupX',
      position: 'Frontend Developer',
      package: '₹7 LPA',
      selectionDate: '2024-03-02',
      joiningDate: '2024-06-01',
      status: 'confirmed',
      email: 'arjun.singh@college.edu',
      phone: '+91 98765 43214',
      skills: ['React', 'Vue.js', 'CSS', 'JavaScript'],
      photo: 'https://readdy.ai/api/search-image?query=professional%20headshot%20of%20young%20Indian%20male%20frontend%20developer%20wearing%20casual%20shirt%2C%20clean%20studio%20background%2C%20creative%20expression%2C%20modern%20professional%20portrait&width=150&height=150&seq=student5&orientation=squarish'
    },
    {
      id: 6,
      name: 'Kavya Nair',
      rollNumber: 'CS2020034',
      department: 'Computer Science',
      cgpa: 8.8,
      company: 'GlobalTech Solutions',
      position: 'Quality Assurance Engineer',
      package: '₹6 LPA',
      selectionDate: '2024-02-26',
      joiningDate: '2024-07-01',
      status: 'confirmed',
      email: 'kavya.nair@college.edu',
      phone: '+91 98765 43215',
      skills: ['Selenium', 'TestNG', 'Java', 'API Testing'],
      photo: 'https://readdy.ai/api/search-image?query=professional%20headshot%20of%20young%20Indian%20female%20QA%20engineer%20wearing%20professional%20attire%2C%20clean%20studio%20background%2C%20focused%20expression%2C%20modern%20professional%20portrait&width=150&height=150&seq=student6&orientation=squarish'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const companies = [...new Set(selectedStudents.map(student => student.company))];
  const departments = [...new Set(selectedStudents.map(student => student.department))];

  const filteredStudents = selectedStudents.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.rollNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCompany = companyFilter === 'all' || student.company === companyFilter;
    const matchesDepartment = departmentFilter === 'all' || student.department === departmentFilter;
    return matchesSearch && matchesCompany && matchesDepartment;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <div className="w-5 h-5 flex items-center justify-center">
              <i className="ri-search-line text-gray-400"></i>
            </div>
          </div>
          <input
            type="text"
            placeholder="Search students..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={companyFilter}
            onChange={(e) => setCompanyFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm pr-8"
          >
            <option value="all">All Companies</option>
            {companies.map(company => (
              <option key={company} value={company}>{company}</option>
            ))}
          </select>

          <select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm pr-8"
          >
            <option value="all">All Departments</option>
            {departments.map(dept => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-white border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company & Position
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Package
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Joining Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredStudents.map((student) => (
                <tr key={student.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-12 w-12">
                        <img 
                          className="h-12 w-12 rounded-full object-cover object-top" 
                          src={student.photo} 
                          alt={student.name}
                        />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{student.name}</div>
                        <div className="text-sm text-gray-500">{student.rollNumber}</div>
                        <div className="text-sm text-gray-500">{student.department}</div>
                        <div className="text-sm text-gray-500">CGPA: {student.cgpa}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{student.company}</div>
                    <div className="text-sm text-gray-500">{student.position}</div>
                    <div className="text-sm text-gray-500">Selected: {new Date(student.selectionDate).toLocaleDateString()}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-semibold text-green-600">{student.package}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(student.status)}`}>
                      {student.status.charAt(0).toUpperCase() + student.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {new Date(student.joiningDate).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex gap-2">
                      <button className="text-blue-600 hover:text-blue-800 cursor-pointer">
                        <div className="w-4 h-4 flex items-center justify-center">
                          <i className="ri-eye-line"></i>
                        </div>
                      </button>
                      <button className="text-gray-600 hover:text-gray-800 cursor-pointer">
                        <div className="w-4 h-4 flex items-center justify-center">
                          <i className="ri-download-line"></i>
                        </div>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredStudents.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 flex items-center justify-center mx-auto mb-4 bg-gray-100 rounded-full">
            <i className="ri-user-star-line text-gray-400 text-2xl"></i>
          </div>
          <p className="text-gray-500">No selected students found matching your criteria</p>
        </div>
      )}

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center">
          <div className="w-5 h-5 flex items-center justify-center mr-3">
            <i className="ri-information-line text-blue-600"></i>
          </div>
          <div>
            <h3 className="text-sm font-medium text-blue-900">Placement Statistics</h3>
            <p className="text-sm text-blue-700">
              Total Selected: {selectedStudents.length} students | 
              Confirmed: {selectedStudents.filter(s => s.status === 'confirmed').length} | 
              Pending: {selectedStudents.filter(s => s.status === 'pending').length}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
