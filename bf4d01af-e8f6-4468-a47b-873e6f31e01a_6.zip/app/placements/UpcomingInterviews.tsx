
'use client';

import { useState } from 'react';

export default function UpcomingInterviews() {
  const [filterType, setFilterType] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const interviews = [
    {
      id: 1,
      company: 'TechCorp Solutions',
      position: 'Software Engineer',
      date: '2024-02-20',
      time: '10:00 AM',
      type: 'technical',
      location: 'Room 301',
      interviewer: 'Mr. Rajesh Kumar',
      candidates: [
        { name: 'Rahul Sharma', rollNumber: 'CS2020001', status: 'confirmed' },
        { name: 'Priya Patel', rollNumber: 'CS2020045', status: 'confirmed' },
        { name: 'Amit Kumar', rollNumber: 'CS2020023', status: 'pending' }
      ],
      duration: '2 hours',
      instructions: 'Bring laptop with development environment setup',
      status: 'scheduled'
    },
    {
      id: 2,
      company: 'DataFlow Analytics',
      position: 'Data Scientist',
      date: '2024-02-25',
      time: '2:00 PM',
      type: 'hr',
      location: 'Conference Room A',
      interviewer: 'Ms. Anjali Mehta',
      candidates: [
        { name: 'Sneha Reddy', rollNumber: 'ME2020012', status: 'confirmed' },
        { name: 'Arjun Singh', rollNumber: 'CS2020067', status: 'confirmed' }
      ],
      duration: '45 minutes',
      instructions: 'Prepare for behavioral questions and salary discussion',
      status: 'scheduled'
    },
    {
      id: 3,
      company: 'CloudTech Systems',
      position: 'DevOps Engineer',
      date: '2024-02-28',
      time: '11:00 AM',
      type: 'technical',
      location: 'Lab 205',
      interviewer: 'Mr. Vikram Gupta',
      candidates: [
        { name: 'Kavya Nair', rollNumber: 'CS2020034', status: 'confirmed' },
        { name: 'Rohan Joshi', rollNumber: 'CS2020078', status: 'confirmed' },
        { name: 'Meera Shah', rollNumber: 'CS2020089', status: 'pending' }
      ],
      duration: '3 hours',
      instructions: 'Hands-on coding and system design problems',
      status: 'scheduled'
    },
    {
      id: 4,
      company: 'FinanceFlow Inc',
      position: 'Business Analyst',
      date: '2024-03-02',
      time: '9:00 AM',
      type: 'group',
      location: 'Auditorium',
      interviewer: 'Team Lead Panel',
      candidates: [
        { name: 'Deepak Yadav', rollNumber: 'ME2020045', status: 'confirmed' },
        { name: 'Sanya Kapoor', rollNumber: 'EC2020023', status: 'confirmed' },
        { name: 'Nikhil Agarwal', rollNumber: 'CS2020056', status: 'confirmed' },
        { name: 'Pooja Sharma', rollNumber: 'ME2020067', status: 'pending' }
      ],
      duration: '4 hours',
      instructions: 'Group discussion and case study analysis',
      status: 'scheduled'
    },
    {
      id: 5,
      company: 'StartupX',
      position: 'Frontend Developer',
      date: '2024-03-05',
      time: '3:00 PM',
      type: 'technical',
      location: 'Room 401',
      interviewer: 'Mr. Ashish Patel',
      candidates: [
        { name: 'Ravi Kumar', rollNumber: 'CS2020012', status: 'confirmed' },
        { name: 'Shreya Bansal', rollNumber: 'CS2020034', status: 'rescheduled' }
      ],
      duration: '1.5 hours',
      instructions: 'Live coding session with React components',
      status: 'rescheduled'
    }
  ];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'technical': return 'bg-blue-100 text-blue-800';
      case 'hr': return 'bg-green-100 text-green-800';
      case 'group': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rescheduled': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'technical': return 'ri-code-line';
      case 'hr': return 'ri-user-heart-line';
      case 'group': return 'ri-team-line';
      default: return 'ri-user-voice-line';
    }
  };

  const filteredInterviews = interviews.filter(interview => {
    const matchesType = filterType === 'all' || interview.type === filterType;
    const matchesSearch = interview.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         interview.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         interview.interviewer.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <div className="w-5 h-5 flex items-center justify-center">
              <i className="ri-search-line text-gray-400"></i>
            </div>
          </div>
          <input
            type="text"
            placeholder="Search interviews..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm pr-8"
          >
            <option value="all">All Types</option>
            <option value="technical">Technical</option>
            <option value="hr">HR</option>
            <option value="group">Group</option>
          </select>
          
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap text-sm">
            <div className="w-4 h-4 flex items-center justify-center mr-2 inline-block">
              <i className="ri-calendar-event-line"></i>
            </div>
            Schedule Interview
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {filteredInterviews.map((interview) => (
          <div key={interview.id} className="bg-white border rounded-lg p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-semibold text-gray-900">{interview.company}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(interview.type)}`}>
                    <div className="w-3 h-3 flex items-center justify-center mr-1 inline-block">
                      <i className={getTypeIcon(interview.type)}></i>
                    </div>
                    {interview.type.charAt(0).toUpperCase() + interview.type.slice(1)}
                  </span>
                </div>
                <p className="text-blue-600 font-medium mb-1">{interview.position}</p>
                <p className="text-gray-600">Interviewer: {interview.interviewer}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(interview.status)}`}>
                {interview.status.charAt(0).toUpperCase() + interview.status.slice(1)}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-calendar-line"></i>
                </div>
                {new Date(interview.date).toLocaleDateString()}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-time-line"></i>
                </div>
                {interview.time} ({interview.duration})
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-map-pin-line"></i>
                </div>
                {interview.location}
              </div>
            </div>

            <div className="mb-4">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Instructions:</h4>
              <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">{interview.instructions}</p>
            </div>

            <div className="mb-4">
              <h4 className="text-sm font-medium text-gray-900 mb-3">
                Candidates ({interview.candidates.length})
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {interview.candidates.map((candidate, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{candidate.name}</p>
                      <p className="text-xs text-gray-600">{candidate.rollNumber}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(candidate.status)}`}>
                      {candidate.status.charAt(0).toUpperCase() + candidate.status.slice(1)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t">
              <div className="flex items-center gap-4">
                <span className="text-sm text-gray-600">
                  {interview.candidates.filter(c => c.status === 'confirmed').length} confirmed
                </span>
                <span className="text-sm text-gray-600">
                  {interview.candidates.filter(c => c.status === 'pending').length} pending
                </span>
              </div>

              <div className="flex gap-2">
                <button className="text-blue-600 hover:text-blue-800 cursor-pointer text-sm px-3 py-1 rounded hover:bg-blue-50">
                  <div className="w-4 h-4 flex items-center justify-center mr-1 inline-block">
                    <i className="ri-edit-line"></i>
                  </div>
                  Edit
                </button>
                <button className="text-green-600 hover:text-green-800 cursor-pointer text-sm px-3 py-1 rounded hover:bg-green-50">
                  <div className="w-4 h-4 flex items-center justify-center mr-1 inline-block">
                    <i className="ri-mail-line"></i>
                  </div>
                  Notify
                </button>
                <button className="text-gray-600 hover:text-gray-800 cursor-pointer text-sm px-3 py-1 rounded hover:bg-gray-50">
                  <div className="w-4 h-4 flex items-center justify-center mr-1 inline-block">
                    <i className="ri-more-line"></i>
                  </div>
                  More
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredInterviews.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 flex items-center justify-center mx-auto mb-4 bg-gray-100 rounded-full">
            <i className="ri-calendar-event-line text-gray-400 text-2xl"></i>
          </div>
          <p className="text-gray-500">No interviews found matching your criteria</p>
        </div>
      )}

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex items-center">
          <div className="w-5 h-5 flex items-center justify-center mr-3">
            <i className="ri-alarm-line text-amber-600"></i>
          </div>
          <div>
            <h3 className="text-sm font-medium text-amber-900">Upcoming Reminders</h3>
            <p className="text-sm text-amber-700">
              Send interview reminders to candidates 24 hours before scheduled time
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
