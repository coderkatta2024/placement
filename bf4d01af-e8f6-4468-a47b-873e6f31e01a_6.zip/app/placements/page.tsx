
'use client';

import { useState } from 'react';
import PlacementDrives from './PlacementDrives';
import SelectedStudents from './SelectedStudents';
import PlacementCalendar from './PlacementCalendar';
import UpcomingInterviews from './UpcomingInterviews';

export default function PlacementsPage() {
  const [activeTab, setActiveTab] = useState('drives');

  const tabs = [
    { id: 'drives', label: 'Placement Drives', icon: 'ri-building-line' },
    { id: 'selected', label: 'Selected Students', icon: 'ri-user-star-line' },
    { id: 'calendar', label: 'Calendar', icon: 'ri-calendar-line' },
    { id: 'interviews', label: 'Interviews', icon: 'ri-video-line' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Placement Management</h1>
          <p className="text-gray-600">Manage placement drives, track selections, and schedule interviews</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border mb-6">
          <div className="flex border-b overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-6 py-4 font-medium text-sm whitespace-nowrap cursor-pointer transition-colors ${
                  activeTab === tab.id
                    ? 'border-b-2 border-blue-600 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <div className="w-5 h-5 flex items-center justify-center mr-2">
                  <i className={tab.icon}></i>
                </div>
                {tab.label}
              </button>
            ))}
          </div>

          <div className="p-6">
            {activeTab === 'drives' && <PlacementDrives />}
            {activeTab === 'selected' && <SelectedStudents />}
            {activeTab === 'calendar' && <PlacementCalendar />}
            {activeTab === 'interviews' && <UpcomingInterviews />}
          </div>
        </div>
      </div>
    </div>
  );
}
