
'use client';

import { useState } from 'react';

interface Student {
  id: string;
  name: string;
  email: string;
  course: string;
  year: string;
  cgpa: number;
  skills: string[];
  status: 'active' | 'placed' | 'inactive';
  placedAt?: string;
}

export default function StudentList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  
  // Mock data
  const students: Student[] = [
    {
      id: 'ST001',
      name: 'Alex Johnson',
      email: 'alex.johnson@college.edu',
      course: 'Computer Science',
      year: '4th Year',
      cgpa: 8.5,
      skills: ['React', 'Node.js', 'Python', 'MongoDB'],
      status: 'placed',
      placedAt: 'Google'
    },
    {
      id: 'ST002',
      name: 'Sarah Chen',
      email: 'sarah.chen@college.edu',
      course: 'Data Science',
      year: '4th Year',
      cgpa: 9.1,
      skills: ['Python', 'Machine Learning', 'TensorFlow', 'SQL'],
      status: 'placed',
      placedAt: 'Microsoft'
    },
    {
      id: 'ST003',
      name: 'Raj Patel',
      email: 'raj.patel@college.edu',
      course: 'Marketing',
      year: '3rd Year',
      cgpa: 8.2,
      skills: ['Digital Marketing', 'SEO', 'Analytics', 'Content Strategy'],
      status: 'active'
    },
    {
      id: 'ST004',
      name: 'Emily Davis',
      email: 'emily.davis@college.edu',
      course: 'Mechanical Engineering',
      year: '4th Year',
      cgpa: 8.7,
      skills: ['AutoCAD', 'SolidWorks', 'MATLAB', 'Project Management'],
      status: 'active'
    },
    {
      id: 'ST005',
      name: 'Michael Brown',
      email: 'michael.brown@college.edu',
      course: 'Finance',
      year: '3rd Year',
      cgpa: 8.0,
      skills: ['Financial Analysis', 'Excel', 'Risk Management', 'Bloomberg'],
      status: 'active'
    },
    {
      id: 'ST006',
      name: 'Lisa Wang',
      email: 'lisa.wang@college.edu',
      course: 'Computer Science',
      year: '4th Year',
      cgpa: 9.3,
      skills: ['Java', 'Spring Boot', 'AWS', 'Docker'],
      status: 'placed',
      placedAt: 'Amazon'
    },
    {
      id: 'ST007',
      name: 'James Wilson',
      email: 'james.wilson@college.edu',
      course: 'Electrical Engineering',
      year: '4th Year',
      cgpa: 8.4,
      skills: ['Circuit Design', 'VHDL', 'Embedded Systems', 'IoT'],
      status: 'active'
    },
    {
      id: 'ST008',
      name: 'Anna Martinez',
      email: 'anna.martinez@college.edu',
      course: 'Psychology',
      year: '3rd Year',
      cgpa: 8.8,
      skills: ['Research', 'Statistical Analysis', 'Counseling', 'SPSS'],
      status: 'active'
    }
  ];
  
  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.course.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterStatus === 'all' || student.status === filterStatus;
    
    return matchesSearch && matchesFilter;
  });
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'placed': return 'bg-green-100 text-green-800';
      case 'active': return 'bg-blue-100 text-blue-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Registered Students</h2>
        <p className="text-gray-600">Browse and manage student profiles</p>
      </div>
      
      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <div className="w-5 h-5 flex items-center justify-center">
                <i className="ri-search-line text-gray-400"></i>
              </div>
            </div>
            <input
              type="text"
              placeholder="Search students..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
              filterStatus === 'all' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            All Students
          </button>
          <button
            onClick={() => setFilterStatus('active')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
              filterStatus === 'active' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Active
          </button>
          <button
            onClick={() => setFilterStatus('placed')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
              filterStatus === 'placed' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Placed
          </button>
        </div>
      </div>
      
      {/* Students Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStudents.map(student => (
          <div key={student.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                  {student.name.charAt(0)}
                </div>
                <div className="ml-3">
                  <h3 className="font-semibold text-gray-900">{student.name}</h3>
                  <p className="text-sm text-gray-600">{student.id}</p>
                </div>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(student.status)}`}>
                {student.status === 'placed' ? 'Placed' : student.status === 'active' ? 'Active' : 'Inactive'}
              </span>
            </div>
            
            <div className="space-y-2 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-mail-line"></i>
                </div>
                {student.email}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-book-line"></i>
                </div>
                {student.course} • {student.year}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-star-line"></i>
                </div>
                CGPA: {student.cgpa}
              </div>
              {student.placedAt && (
                <div className="flex items-center text-sm text-green-600">
                  <div className="w-4 h-4 flex items-center justify-center mr-2">
                    <i className="ri-building-line"></i>
                  </div>
                  Placed at {student.placedAt}
                </div>
              )}
            </div>
            
            <div className="mb-4">
              <p className="text-sm text-gray-600 mb-2">Skills:</p>
              <div className="flex flex-wrap gap-1">
                {student.skills.slice(0, 3).map(skill => (
                  <span key={skill} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                    {skill}
                  </span>
                ))}
                {student.skills.length > 3 && (
                  <span className="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded-full">
                    +{student.skills.length - 3} more
                  </span>
                )}
              </div>
            </div>
            
            <div className="flex gap-2">
              <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                View Profile
              </button>
              <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-more-line text-gray-600"></i>
                </div>
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {filteredStudents.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="ri-user-search-line text-2xl text-gray-400"></i>
          </div>
          <p className="text-gray-600">No students found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}
