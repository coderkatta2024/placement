
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import StudentRegistration from './StudentRegistration';
import StudentList from './StudentList';
import { useState } from 'react';

export default function StudentsPage() {
  const [activeTab, setActiveTab] = useState('register');

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Student Portal</h1>
          <p className="text-gray-600">Register your profile and manage your placement journey</p>
        </div>
        
        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-8 bg-gray-200 p-1 rounded-full w-fit">
          <button
            onClick={() => setActiveTab('register')}
            className={`px-6 py-2 rounded-full font-medium transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'register'
                ? 'bg-blue-600 text-white'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Student Registration
          </button>
          <button
            onClick={() => setActiveTab('list')}
            className={`px-6 py-2 rounded-full font-medium transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'list'
                ? 'bg-blue-600 text-white'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Registered Students
          </button>
        </div>
        
        {/* Tab Content */}
        {activeTab === 'register' && <StudentRegistration />}
        {activeTab === 'list' && <StudentList />}
      </div>
      
      <Footer />
    </div>
  );
}
