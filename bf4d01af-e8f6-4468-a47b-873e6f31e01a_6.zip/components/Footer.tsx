
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-bold text-blue-400 mb-4" style={{ fontFamily: 'Pacifico, serif' }}>
              Dr. D.Y. Patil COE
            </div>
            <p className="text-gray-400 mb-4">
              Dr. D.Y. Patil Pratishthan's College of Engineering, Salokhenagar, Kolhapur
            </p>
            <p className="text-gray-400 text-sm">
              Empowering engineering minds to build tomorrow's innovations.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/students" className="text-gray-400 hover:text-white cursor-pointer">Student Registration</Link></li>
              <li><Link href="/companies" className="text-gray-400 hover:text-white cursor-pointer">Company Partnerships</Link></li>
              <li><Link href="/placements" className="text-gray-400 hover:text-white cursor-pointer">Placement Drives</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><Link href="/analytics" className="text-gray-400 hover:text-white cursor-pointer">Analytics</Link></li>
              <li><Link href="/admin" className="text-gray-400 hover:text-white cursor-pointer">Admin Portal</Link></li>
              <li><a href="#" className="text-gray-400 hover:text-white cursor-pointer">Academic Calendar</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <div className="space-y-2 text-gray-400">
              <p>Email: placement@dypatil.edu</p>
              <p>Phone: +91 231 2601234</p>
              <p>Address: Salokhenagar, Kolhapur, Maharashtra 416003</p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Dr. D.Y. Patil Pratishthan's College of Engineering. All rights reserved.</p>
          <p className="mt-2 text-sm">Developed by Mr. G. B. Kadam</p>
        </div>
      </div>
    </footer>
  );
}