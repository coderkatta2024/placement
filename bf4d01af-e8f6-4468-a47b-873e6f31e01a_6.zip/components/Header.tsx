
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold text-blue-600" style={{ fontFamily: 'Pacifico, serif' }}>
              Dr. D.Y. Patil COE
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Home
            </Link>
            <Link href="/students" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Students
            </Link>
            <Link href="/companies" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Companies
            </Link>
            <Link href="/placements" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Placements
            </Link>
            <Link href="/analytics" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Analytics
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Link href="/admin" className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
              Admin Login
            </Link>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-blue-600 cursor-pointer"
            >
              <div className="w-6 h-6 flex items-center justify-center">
                <i className="ri-menu-line text-xl"></i>
              </div>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <div className="flex flex-col space-y-2">
              <Link href="/" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Home
              </Link>
              <Link href="/students" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Students
              </Link>
              <Link href="/companies" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Companies
              </Link>
              <Link href="/placements" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Placements
              </Link>
              <Link href="/analytics" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Analytics
              </Link>
              <Link href="/admin" className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap inline-block">
                Admin Login
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}