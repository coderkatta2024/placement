import { 
  collection, 
  addDoc, 
  getDocs, 
  doc, 
  getDoc, 
  updateDoc, 
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  Timestamp
} from 'firebase/firestore';
import { db } from './firebase';

// Admin Users Collection
export const adminUsersCollection = collection(db, 'adminUsers');

// Companies Collection
export const companiesCollection = collection(db, 'companies');

// Students Collection
export const studentsCollection = collection(db, 'students');

// Placements Collection
export const placementsCollection = collection(db, 'placements');

// Analytics Collection
export const analyticsCollection = collection(db, 'analytics');

// Admin User Functions
export const createAdminUser = async (adminData: any) => {
  try {
    const docRef = await addDoc(adminUsersCollection, {
      ...adminData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating admin user:', error);
    throw error;
  }
};

export const getAdminUser = async (username: string) => {
  try {
    const q = query(adminUsersCollection, where('username', '==', username));
    const querySnapshot = await getDocs(q);
    
    if (!querySnapshot.empty) {
      const doc = querySnapshot.docs[0];
      return { id: doc.id, ...doc.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting admin user:', error);
    throw error;
  }
};

export const getAllAdminUsers = async () => {
  try {
    const querySnapshot = await getDocs(adminUsersCollection);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error getting admin users:', error);
    throw error;
  }
};

// Company Functions
export const createCompany = async (companyData: any) => {
  try {
    const docRef = await addDoc(companiesCollection, {
      ...companyData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating company:', error);
    throw error;
  }
};

export const getAllCompanies = async () => {
  try {
    const querySnapshot = await getDocs(companiesCollection);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error getting companies:', error);
    throw error;
  }
};

export const getCompanyById = async (id: string) => {
  try {
    const docRef = doc(companiesCollection, id);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting company:', error);
    throw error;
  }
};

export const updateCompany = async (id: string, companyData: any) => {
  try {
    const docRef = doc(companiesCollection, id);
    await updateDoc(docRef, {
      ...companyData,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating company:', error);
    throw error;
  }
};

export const deleteCompany = async (id: string) => {
  try {
    const docRef = doc(companiesCollection, id);
    await deleteDoc(docRef);
  } catch (error) {
    console.error('Error deleting company:', error);
    throw error;
  }
};

// Student Functions
export const createStudent = async (studentData: any) => {
  try {
    const docRef = await addDoc(studentsCollection, {
      ...studentData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating student:', error);
    throw error;
  }
};

export const getAllStudents = async () => {
  try {
    const querySnapshot = await getDocs(studentsCollection);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error getting students:', error);
    throw error;
  }
};

export const getStudentById = async (id: string) => {
  try {
    const docRef = doc(studentsCollection, id);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting student:', error);
    throw error;
  }
};

export const updateStudent = async (id: string, studentData: any) => {
  try {
    const docRef = doc(studentsCollection, id);
    await updateDoc(docRef, {
      ...studentData,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating student:', error);
    throw error;
  }
};

export const deleteStudent = async (id: string) => {
  try {
    const docRef = doc(studentsCollection, id);
    await deleteDoc(docRef);
  } catch (error) {
    console.error('Error deleting student:', error);
    throw error;
  }
};

// Placement Functions
export const createPlacement = async (placementData: any) => {
  try {
    const docRef = await addDoc(placementsCollection, {
      ...placementData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating placement:', error);
    throw error;
  }
};

export const getAllPlacements = async () => {
  try {
    const querySnapshot = await getDocs(placementsCollection);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error getting placements:', error);
    throw error;
  }
};

export const getPlacementById = async (id: string) => {
  try {
    const docRef = doc(placementsCollection, id);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting placement:', error);
    throw error;
  }
};

export const updatePlacement = async (id: string, placementData: any) => {
  try {
    const docRef = doc(placementsCollection, id);
    await updateDoc(docRef, {
      ...placementData,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating placement:', error);
    throw error;
  }
};

export const deletePlacement = async (id: string) => {
  try {
    const docRef = doc(placementsCollection, id);
    await deleteDoc(docRef);
  } catch (error) {
    console.error('Error deleting placement:', error);
    throw error;
  }
};

// Analytics Functions
export const createAnalytics = async (analyticsData: any) => {
  try {
    const docRef = await addDoc(analyticsCollection, {
      ...analyticsData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating analytics:', error);
    throw error;
  }
};

export const getAllAnalytics = async () => {
  try {
    const querySnapshot = await getDocs(analyticsCollection);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error getting analytics:', error);
    throw error;
  }
};

// Recent Activities
export const getRecentActivities = async (limitCount: number = 10) => {
  try {
    const q = query(
      collection(db, 'activities'),
      orderBy('createdAt', 'desc'),
      limit(limitCount)
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error getting recent activities:', error);
    throw error;
  }
};

// Dashboard Stats
export const getDashboardStats = async () => {
  try {
    const [studentsSnapshot, companiesSnapshot, placementsSnapshot] = await Promise.all([
      getDocs(studentsCollection),
      getDocs(companiesCollection),
      getDocs(placementsCollection)
    ]);

    return {
      totalStudents: studentsSnapshot.size,
      totalCompanies: companiesSnapshot.size,
      totalPlacements: placementsSnapshot.size,
      placementRate: placementsSnapshot.size > 0 ? ((placementsSnapshot.size / studentsSnapshot.size) * 100).toFixed(1) : '0'
    };
  } catch (error) {
    console.error('Error getting dashboard stats:', error);
    throw error;
  }
};